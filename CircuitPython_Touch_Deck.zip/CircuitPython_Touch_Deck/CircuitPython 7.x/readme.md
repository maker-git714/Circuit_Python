This is the source code for Touch Deck Guide Project:
https://learn.adafruit.com/touch-deck-lcd-control-pad/